package pageObjects;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.Scenario;

public class Pages {

	WebDriverWait wait;
	public WebDriver idriver;
	
	public Pages(WebDriver driver)
	{
		idriver =driver;
		PageFactory.initElements(driver, this);
		
	}
	
	@FindBy(id="logo")
	@CacheLookup
	WebElement NHSLogo;
		
	@FindBy(id="next-button")
	@CacheLookup
	WebElement Startbutton;
	
	@FindBy(xpath="//h1[contains(text(),'Which country do you live in?')]")
	@CacheLookup
	WebElement countrydoyoulivein;
	
	@FindBy(css="#label-wales")
	@CacheLookup
	WebElement countryradiobutton;
	
	@FindBy(css="#next-button")
	@CacheLookup
	WebElement nextelement;
			
	@FindBy(xpath="//h1[contains(text(),'What is your date of birth?')]")
	@CacheLookup
	WebElement dateofbirth;
	
	@FindBy(css="#next-button")
	@CacheLookup
	WebElement nextelement1;
	
	@FindBy(id="dob-day")
	@CacheLookup
	WebElement Bdayday;
	
	@FindBy(css="#next-button")
	@CacheLookup
	WebElement nextelement2;
	
	@FindBy(id="dob-month")
	@CacheLookup
	WebElement Bdaymonth;
	
	@FindBy(css="#next-button")
	@CacheLookup
	WebElement nextelement3;
	
	@FindBy(id="dob-year")
	@CacheLookup
	WebElement Bdayyear;
	
	@FindBy(css="#next-button")
	@CacheLookup
	WebElement nextelement4;
			
	@FindBy(xpath="//html")
	@CacheLookup
	WebElement Blankclick;
	
	@FindBy(css="#next-button")
	@CacheLookup
	WebElement nextelement5;
	
	@FindBy(xpath="//h1[contains(text(),'Do you live with a partner?')]")
	@CacheLookup
	WebElement livewithyourpartnerpage;
	
	@FindBy(css="#next-button")
	@CacheLookup
	WebElement nextelement6;
	
	@FindBy(css="#label-yes")
	@CacheLookup
	WebElement Yesradiobutton;
	
	@FindBy(css="#label-no")
	@CacheLookup
	WebElement Noradiobutton;
	
	@FindBy(xpath="//h1/span[contains(text(),'Do you or your partner claim any benefits or tax credits?')]")
	@CacheLookup
	WebElement claimanybenifitsortaxcreditspage;
	
	@FindBy(css="#label-yes")
	@CacheLookup
	WebElement Yesradiobutton8;
	
	@FindBy(css="#label-no")
	@CacheLookup
	WebElement Noradiobutton8;
	
	@FindBy(css="#next-button")
	@CacheLookup
	WebElement nextelement7;
	
	@FindBy(css="#label-yes")
	@CacheLookup
	WebElement Yesradiobutton1;
	
	@FindBy(css="#label-no")
	@CacheLookup
	WebElement Noradiobutton1;
	
	@FindBy(xpath="//h1[contains(text(),'Are you pregnant or have you given birth in the last 12 months?')]")
	@CacheLookup
	WebElement pregnantOrGivenBirthinthelast12Monthspage;
	
	@FindBy(css="#next-button")
	@CacheLookup
	WebElement nextelement8;
	
	@FindBy(css="#label-yes")
	@CacheLookup
	WebElement Yesradiobutton2;
	
	@FindBy(css="#label-no")
	@CacheLookup
	WebElement Noradiobutton2;
	
	@FindBy(xpath="//h1[contains(text(),'Do you have an injury or illness caused by serving in the armed forces?')]")
	@CacheLookup
	WebElement injuryorillnesscausedbyservinginthearmedforcespage;
	

	@FindBy(css="#next-button")
	@CacheLookup
	WebElement nextelement9;
	
	@FindBy(css="#label-yes")
	@CacheLookup
	WebElement Yesradiobutton3;
	
	@FindBy(css="#label-no")
	@CacheLookup
	WebElement Noradiobutton3;
	
	@FindBy(xpath="//h1[contains(text(),'Do you have diabetes?')]")
	@CacheLookup
	WebElement doyouhavediabeticspage;
	
	@FindBy(css="#label-yes")
	@CacheLookup
	WebElement Yesradiobutton4;
	
	@FindBy(css="#label-no")
	@CacheLookup
	WebElement Noradiobutton4;
	
	@FindBy(xpath="//h1/span[contains(text(),'Do you have glaucoma?')]")
	@CacheLookup
	WebElement doyouhaveGloucamapage;
	
	@FindBy(css="#label-yes")
	@CacheLookup
	WebElement Yesradiobutton5;
	
	@FindBy(css="#label-no")
	@CacheLookup
	WebElement Noradiobutton5;
	
	@FindBy(xpath="//h1/span[contains(text(),'Do you or your partner live permanently in a care home?')]")
	@CacheLookup
	WebElement doyourpartnerlivepermanentlyinacarehomepage;
	
	@FindBy(css="#label-yes")
	@CacheLookup
	WebElement Yesradiobutton6;
	
	@FindBy(css="#label-no")
	@CacheLookup
	WebElement Noradiobutton6;
		
	@FindBy(xpath="//h1[contains(text(),'Do you get help to pay for your care home from your local council?')]")
	@CacheLookup
	WebElement payforyourcarehomefromyourlocalcouncilpage;
	
	@FindBy(css=".done-panel")
	@CacheLookup
	WebElement nhsCosts;
	
	@FindBy(xpath="//h1[contains(text(), 'Do you or your partner get paid Universal Credit?')]")
	@CacheLookup
	WebElement partnerGetPaidUniversalCredit;
	
	@FindBy(css="label[for='yes-universal']")
	@CacheLookup
	WebElement yesUniversalPayments;
	
	@FindBy(css="#next-button")
	@CacheLookup
	WebElement nextelement10;
	
	@FindBy(xpath="//h1/span[contains(text(),\"As part of your joint Universal Credit, do you have any of these?\")]")
	@CacheLookup
	WebElement partOfYourJointUniversalCreditDoYouHaveAnyOfThesepage;
	
	@FindBy(css="#label-yes")
	@CacheLookup
	WebElement yespartOfYourJointUniversalCreditDoYouHaveAnyOfThese;
	
	@FindBy(css="#label-no")
	@CacheLookup
	WebElement nopartOfYourJointUniversalCreditDoYouHaveAnyOfThese;
	
	@FindBy(css="#next-button")
	@CacheLookup
	WebElement partOfYourJointUniversalCreditDoYouHaveAnyOfThesepagenext;
	
	@FindBy(xpath="//h1/span[contains(text(),'Did you and your partner have a combined take-home pay of £935 or less in your last Universal Credit period?')]")
	@CacheLookup
	WebElement combinedTakeHomePayOrLessInYourLastUniCreditpage;
	
	@FindBy(css="#label-yes")
	@CacheLookup
	WebElement yescombinedTakeHomePayOrLessInYourLastUniCredit;
	
	@FindBy(css="#label-no")
	@CacheLookup
	WebElement nocombinedTakeHomePayOrLessInYourLastUniCredit;
	
	@FindBy(css="#next-button")
	@CacheLookup
	WebElement combinedTakeHomePayOrLessInYourLastUniCreditpagenext;
	
	public void launchUrl(String url)
	{
		idriver.manage().timeouts().implicitlyWait(15,TimeUnit.SECONDS);
		idriver.manage().window().maximize();
		idriver.get(url);	
	}
	
	
	public void startApplication()
	{
	
		if (NHSLogo.isDisplayed())
		{			
			
			JavascriptExecutor js = (JavascriptExecutor) idriver;
			js.executeScript("arguments[0].scrollIntoView();",Startbutton );
			Startbutton.click();	
		}
		else
			System.out.println("Element is not displayed");
	}
	
	
	public void countryLivingIn()
	{
		
		wait=new WebDriverWait(idriver,30);		
		wait.until(ExpectedConditions.textToBePresentInElement(countrydoyoulivein, "Which country do you live in?"));		
		countryradiobutton.click();
		nextelement.click();
				
	}
	
	public void enterDateOfBirth(String date,String month,String year)
	
	{
		Bdayday.sendKeys(date);
		Bdaymonth.sendKeys(month);
		Bdayyear.sendKeys(year);
		Blankclick.click();		
		nextelement1.click();
		
	}
	
	public void doYouLiveWithYourPartner(String radiobuttonvalue)
	
	{	
		wait.until(ExpectedConditions.textToBePresentInElement(livewithyourpartnerpage, "Do you live with a partner?"));
		if (radiobuttonvalue.equalsIgnoreCase("Yes"))
		{
		Yesradiobutton.click();
		}
		else
		{
			Noradiobutton.click();
		}
		nextelement2.click();
	}
	
	public void claimanybenifitsortaxcredits(String radiobuttonvalue )
	{
				
		wait.until(ExpectedConditions.textToBePresentInElement(claimanybenifitsortaxcreditspage, "Do you or your partner claim any benefits or tax credits?"));
		if (radiobuttonvalue.equalsIgnoreCase("Yes"))
		{
		Yesradiobutton8.click();
		}
		else
		{
			Noradiobutton8.click();
		}
		nextelement3.click();				
											
	}
	
	public void pregnantOrGivenBirthinthelast12Months(String radiobuttonvalue)
	{
		wait.until(ExpectedConditions.textToBePresentInElement(pregnantOrGivenBirthinthelast12Monthspage, "Are you pregnant or have you given birth in the last 12 months?"));
		if (radiobuttonvalue.equalsIgnoreCase("Yes"))
		{
		Yesradiobutton1.click();
		}
		else
		{
			Noradiobutton1.click();
		}
		nextelement4.click();					
	}
	
	public void injuryorillnesscausedbyservinginthearmedforces(String radiobuttonvalue)
	{
		
		wait.until(ExpectedConditions.textToBePresentInElement(injuryorillnesscausedbyservinginthearmedforcespage, "Do you have an injury or illness caused by serving in the armed forces?"));
		if (radiobuttonvalue.equalsIgnoreCase("Yes"))
		{
		Yesradiobutton2.click();
		}
		else
		{
			Noradiobutton2.click();
		}
		nextelement5.click();				
		
	}
	
	public void doYouHaveDiabetics(String radiobuttonvalue)
	{
		
		wait.until(ExpectedConditions.textToBePresentInElement(doyouhavediabeticspage, "Do you have diabetes?"));
		if (radiobuttonvalue.equalsIgnoreCase("Yes"))
		{
		Yesradiobutton3.click();
		}
		else
		{
			Noradiobutton3.click();
		}
		nextelement6.click();
	}
	
	public void doYouHaveGloucama(String radiobuttonvalue)
	{
		
		
		wait.until(ExpectedConditions.textToBePresentInElement(doyouhaveGloucamapage, "Do you have glaucoma?"));
		if (radiobuttonvalue.equalsIgnoreCase("Yes"))
		{
		Yesradiobutton4.click();
		}
		else
		{
			Noradiobutton4.click();
		}
		nextelement7.click();	
	}
	
	public void doYourPartnerLivePermanentlyInaCareHome(String radiobuttonvalue)
	{
		
		wait.until(ExpectedConditions.textToBePresentInElement(doyourpartnerlivepermanentlyinacarehomepage, "Do you or your partner live permanently in a care home?"));
		
		if (radiobuttonvalue.equalsIgnoreCase("Yes"))
		{
		Yesradiobutton5.click();
		}
		else
		{
			Noradiobutton5.click();
		}
		nextelement8.click();
		
	}
	
	public void PayForYourCareHomeFromYourLocalCouncil(String radiobuttonvalue)
	{
				
		wait.until(ExpectedConditions.textToBePresentInElement(payforyourcarehomefromyourlocalcouncilpage, "Do you get help to pay for your care home from your local council?"));
		if (radiobuttonvalue.equalsIgnoreCase("Yes"))
		{
		Yesradiobutton6.click();
		}
		else
		{
			Noradiobutton6.click();
		}
		nextelement9.click();
	}
	
	public void yourPartnerGetPaidUniversalCredit(String radiobuttonvalue) {
		wait.until(ExpectedConditions.textToBePresentInElement(partnerGetPaidUniversalCredit, "Do you or your partner get paid Universal Credit?"));
		if (radiobuttonvalue.equalsIgnoreCase("Yes, we receive Universal Credit payments"))
		{
			yesUniversalPayments.click();
		}
		nextelement10.click();
	}
	
	public void partOfYourJointUniversalCreditDoYouHaveAnyOfThese(String radiobuttonvalue)
	{		
		wait.until(ExpectedConditions.textToBePresentInElement(partOfYourJointUniversalCreditDoYouHaveAnyOfThesepage, "As part of your joint Universal Credit, do you have any of these?"));
		if (radiobuttonvalue.equalsIgnoreCase("Yes"))
		{
			yespartOfYourJointUniversalCreditDoYouHaveAnyOfThese.click();
		}
		else
		{
			nopartOfYourJointUniversalCreditDoYouHaveAnyOfThese.click();	
		}
		partOfYourJointUniversalCreditDoYouHaveAnyOfThesepagenext.click();
	}
	public void combinedTakeHomePayOrLessInYourLastUniCredit(String radiobuttonvalue)
	{
		wait.until(ExpectedConditions.textToBePresentInElement(combinedTakeHomePayOrLessInYourLastUniCreditpage, "Did you and your partner have a combined take-home pay of £935 or less in your last Universal Credit period?"));
		if (radiobuttonvalue.equalsIgnoreCase("Yes"))
		{
			yescombinedTakeHomePayOrLessInYourLastUniCredit.click();
		}
		else
		{
			nocombinedTakeHomePayOrLessInYourLastUniCredit.click();	
		}
		combinedTakeHomePayOrLessInYourLastUniCreditpagenext.click();
		
	}
	
	public void getNhsCosts() {
		
		String costs = nhsCosts.getText();
		System.out.println(costs);
	}
	
public void takescreenshot() throws Exception
{
	TakesScreenshot ts=(TakesScreenshot)idriver;
	File src=ts.getScreenshotAs(OutputType.FILE);
	FileUtils.copyFile(src, new File("./Screenshot/"+ "Test" + ".png"));
}
	
	

}