package stepDefinitions;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageObjects.Pages;


public class nhs_costs_checker {

	public WebDriver driver;
	
	public Pages pg;
	
	
    @Given("^I navigate to NHS checker tool$")
    public void i_navigate_to_nhs_checker_tool() {
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"//Drivers/chromedriver.exe");
		// System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir")+"//Drivers/geckodriver.exe");
		driver=new ChromeDriver();
		// driver=new FirefoxDriver();
		pg=new Pages(driver);				
		pg.launchUrl("https://services.nhsbsa.nhs.uk/check-for-help-paying-nhs-costs/start");	
		pg.startApplication();		
    }
	
    @Given("^I am \"([^\"]*)\" person$")
    public void i_am_something_person(String country)
    {
    	pg.countryLivingIn();
    	    	
    }

    @When("^I enter my circumstances into the checker tool$")
    public void i_enter_my_circumstances_into_the_checker_tool(DataTable dataSet) {
    	List<List<String>> data = dataSet.asLists();
    	String dob = data.get(1).get(0);
    	String[] dateOfBirth = dob.split("/");
    	pg.enterDateOfBirth(dateOfBirth[0], dateOfBirth[1], dateOfBirth[2]);
    	pg.doYouLiveWithYourPartner(data.get(1).get(1));
    	pg.claimanybenifitsortaxcredits(data.get(1).get(2));
    	pg.pregnantOrGivenBirthinthelast12Months(data.get(1).get(3));
    	pg.injuryorillnesscausedbyservinginthearmedforces(data.get(1).get(4));
    	pg.doYouHaveDiabetics(data.get(1).get(5));
    	pg.doYouHaveGloucama(data.get(1).get(6));
    	pg.doYourPartnerLivePermanentlyInaCareHome(data.get(1).get(7));
    	pg.PayForYourCareHomeFromYourLocalCouncil(data.get(1).get(8));
    }
    
    @When("^I enter my circumstances into the checker tool as below$")
    public void i_enter_my_circumstances_into_the_checker_tool_as_below(DataTable dataSet) {
    	List<List<String>> data = dataSet.asLists();
    	String dob = data.get(1).get(0);
    	String[] dateOfBirth = dob.split("/");
    	pg.enterDateOfBirth(dateOfBirth[0], dateOfBirth[1], dateOfBirth[2]);
    	pg.doYouLiveWithYourPartner(data.get(1).get(1));
    	pg.claimanybenifitsortaxcredits(data.get(1).get(2));
    	pg.yourPartnerGetPaidUniversalCredit(data.get(1).get(3));
    	pg.partOfYourJointUniversalCreditDoYouHaveAnyOfThese(data.get(1).get(4));
    	pg.combinedTakeHomePayOrLessInYourLastUniCredit(data.get(1).get(5));
    }

    @Then("^I should get the results of my NHS costs$")
    public void i_should_get_the_results_of_my_nhs_costs() throws Exception {
		pg.getNhsCosts();
		pg.takescreenshot();
		driver.quit();
				
    }
    }